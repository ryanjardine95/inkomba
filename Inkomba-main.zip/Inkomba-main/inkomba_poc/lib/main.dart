import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:inkomba_poc/screens/giveReferralScreen.dart';
import 'package:inkomba_poc/screens/homeScreenBusiness.dart';
import 'package:inkomba_poc/screens/homeScreenEmployee.dart';
import 'package:inkomba_poc/screens/loginPage.dart';
import 'package:inkomba_poc/screens/workerOrEmployeeScreen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}


class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: {
          '/referrals/': (context) => GiveReferralScreen(),
        },
      debugShowCheckedModeBanner: false,
      title: 'Inkomba Demo',
      theme: ThemeData(
          accentColor: Colors.lightBlue,
          primarySwatch: Colors.lightGreen,
          backgroundColor: Colors.white),
      home: Scaffold(
        body: Container(
          child: StreamBuilder(
            stream: FirebaseAuth.instance.authStateChanges(),
            builder: (ctx, AsyncSnapshot<User?> user) {
              if (user.connectionState == ConnectionState.waiting) {
                return Center(child: CircularProgressIndicator.adaptive());
              } else if (user.data == null) {
                return LoginScreen();
              } else if (user.hasData && user.data != null) {
                return StreamBuilder(
                    stream: FirebaseFirestore.instance
                        .collection('Users')
                        .doc(user.data!.uid)
                        .snapshots(),
                    builder: (ctx,
                        AsyncSnapshot<DocumentSnapshot<Map<String, dynamic>>>
                            snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return Center(
                            child: CircularProgressIndicator.adaptive());
                      } else if (snapshot.data == null) {
                        return LoginScreen();
                      } else {
                        final data = snapshot.data!.data()!['UserType'];
                        if (data == '') {
                          return WorkerOrEmployee();
                        } else if (data == 'Employee') {
                          return HomeScreenEmployee();
                        } else if (data == 'Business') {
                          return HomeScreenBusiness();
                        } else {
                          return Center(
                              child: Text("You're not supposed to be here!"));
                        }
                      }
                    });
              } else {
                return LoginScreen();
              }
            },
          ),
        ),
      ),
    );
  }
}
