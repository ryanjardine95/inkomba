import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class GiveReferralScreen extends StatefulWidget {
  const GiveReferralScreen({Key? key}) : super(key: key);

  @override
  _GiveReferralScreenState createState() => _GiveReferralScreenState();
}

class _GiveReferralScreenState extends State<GiveReferralScreen> {
  @override
  void initState() {
    super.initState();
    initDynamicLinks();
  }

  void initDynamicLinks() async {
    FirebaseDynamicLinks.instance.onLink(
        onSuccess: (PendingDynamicLinkData? dynamicLink) async {
      final Uri? deepLink = dynamicLink?.link;

      if (deepLink != null) {
        if (deepLink.queryParameters.containsKey('id')) {
          String id = deepLink.queryParameters['id']!;
          Navigator.pushNamed(context, deepLink.path, arguments: id);
        } else {
          Navigator.pushNamed(
            context,
            deepLink.path,
          );
        }
      }
    }, onError: (OnLinkErrorException e) async {
      print('onLinkError');
      print(e.message);
    });

    final PendingDynamicLinkData? data =
        await FirebaseDynamicLinks.instance.getInitialLink();
    final Uri? deepLink = data?.link;

    if (deepLink != null) {
      if (deepLink.queryParameters.containsKey('id')) {
        String id = deepLink.queryParameters['id']!;
        Navigator.pushNamed(context, deepLink.path, arguments: id);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    dynamic id = ModalRoute.of(context)!.settings.arguments;
    final TextEditingController referral = new TextEditingController();
    final GlobalKey<FormFieldState> _formKey = new GlobalKey<FormFieldState>();

    Future<void> _trySignUp(BuildContext context) async {
      final db = FirebaseFirestore.instance;
      bool isValid = _formKey.currentState!.validate();

      if (isValid) {
        _formKey.currentState!.save();

        FocusScopeNode currentFocus = FocusScope.of(context);

        if (!currentFocus.hasPrimaryFocus) {
          currentFocus.unfocus();
        }
        final List<String> referralList = [];
        referralList.add(referral.text);
        try {
          await db.collection('Users').doc('$id').set({
            'Referrals': referralList,
          });
          Navigator.pop(context);
        } catch (e) {}
      }
    }

    final TextEditingController _idController = new TextEditingController();
    Widget _referralTextField() {
      return Container(
        child: TextFormField(
          key: _formKey,
          decoration: InputDecoration(hintText: 'Enter Your Referral'),
          autovalidateMode: AutovalidateMode.onUserInteraction,
          controller: referral,
          onChanged: (String value) {
            referral.text = value;
          },
        ),
      );
    }

    return Scaffold(
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: Padding(
        padding: const EdgeInsets.all(8.0),
        child: FloatingActionButton.extended(
          onPressed: () => Navigator.pop(context),
          label: Text('Done!'),
          icon: Icon(Icons.close),
        ),
      ),
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Stack(children: <Widget>[
            Container(
              height: double.infinity,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.blueAccent,
                    Colors.lightBlue,
                    Colors.lightBlueAccent
                  ],
                ),
              ),
            ),
            id != null
                ? Column(
                    children: [
                      _referralTextField(),
                      ElevatedButton(
                          onPressed: () => _trySignUp(context),
                          child: Text('Save'))
                    ],
                  )
                : Column(
                    children: [
                      TextField(
                        controller: _idController,
                        onChanged: (String value) {
                          setState(() {
                            _idController.text = value;
                            id = _idController.text;
                          });
                        },
                        decoration: InputDecoration(
                            hintText: 'User ID- CaSe SeNSitive'),
                      )
                    ],
                  )
          ]),
        ),
      ),
    );
  }
}
