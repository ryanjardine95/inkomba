import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:inkomba_poc/constanstsLogin.dart';
import 'package:inkomba_poc/screens/workerOrEmployeeScreen.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {


  GlobalKey<FormState> _formKey = new GlobalKey<FormState>();
  final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>();

  void _errorSnackBar(BuildContext context, String errorMessage) {
    final snackBar = new SnackBar(
      content: Text(errorMessage),
    );
    scaffoldMessengerKey.currentState!.showSnackBar(snackBar);
  }

  String userName = '';
  String userEmail = '';
  String userSurname = '';
  String password = '';
  int phoneNumber = 27;
  String province = '';

  Future<void> _trySignUp(BuildContext context) async {
    final auth = FirebaseAuth.instance;
    final db = FirebaseFirestore.instance;
    bool isValid = _formKey.currentState!.validate();

    if (isValid) {
      _formKey.currentState!.save();

      print('${userEmail + password}');
      FocusScopeNode currentFocus = FocusScope.of(context);

      if (!currentFocus.hasPrimaryFocus) {
        currentFocus.unfocus();
      }
      try {
        await auth.createUserWithEmailAndPassword(
          email: userEmail,
          password: password,
        );
        final id = auth.currentUser!.uid;
        await db.collection('Users').doc(id).set({
          'Name': '$userName $userSurname',
          'Email': userEmail,
          'Password': password,
          'PhoneNumber': phoneNumber,
          'UserType': '',
          'Province': province
        });
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => WorkerOrEmployee(),
          ),
        );
      } on FirebaseAuthException catch (e) {
        if (e.code == 'weak-password') {
          print('The password provided is too weak.');
          _errorSnackBar(context, 'The password provided is too weak');
        } else if (e.code == 'email-already-in-use') {
          print('The account already exists for that email.');
          _errorSnackBar(context, 'The account already exists for that email.');
        }
      } catch (e) {
        print(e);
      }
    }
  }

  Future<void> _tryLoginUp(BuildContext context) async {
    final auth = FirebaseAuth.instance;
    bool isValid = _formKey.currentState!.validate();
    setState(() {
      _isLoading = true;
    });

    if (isValid) {
      _formKey.currentState!.save();

      print('${userEmail + password}');
      FocusScopeNode currentFocus = FocusScope.of(context);

      if (!currentFocus.hasPrimaryFocus) {
        currentFocus.unfocus();
      }
      try {
        await auth.signInWithEmailAndPassword(
          email: userEmail,
          password: password,
        );
      } on FirebaseAuthException catch (e) {
        if (e.code == 'wrong-password') {
          print('The password Provied is to weak.');
          _errorSnackBar(context, 'Incorrect Password for that User');
        } else if (e.code == 'user-not-found') {
          print('There is no user for that Email');
          _errorSnackBar(context, 'There is no user for that Email');
        }
      } catch (e) {
        print(e);
      }
    }
    setState(() {
      _isLoading = false;
    });
  }

  Widget surnameTf() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Surname',
          style: kLabelStyle,
        ),
        SizedBox(height: 10.0),
        Container(
          alignment: Alignment.centerLeft,
          decoration: kBoxDecorationStyle,
          height: 60.0,
          child: TextFormField(
            autovalidateMode: AutovalidateMode.onUserInteraction,
            autocorrect: false,
            initialValue: userSurname,
            validator: (value) {
              if (value!.isEmpty || value.length < 2) {
                return 'Please enter Valid Name';
              }
              return null;
            },
            onSaved: (newValue) {
              userSurname = newValue!;
            },
            style: TextStyle(
              color: Colors.white,
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.only(top: 14.0),
              prefixIcon: Icon(
                Icons.account_box,
                color: Colors.white,
              ),
              hintText: 'Enter your Surname',
              hintStyle: kHintTextStyle,
            ),
          ),
        ),
      ],
    );
  }

  Widget cellNumberTf() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Cell Number',
          style: kLabelStyle,
        ),
        SizedBox(height: 10.0),
        Container(
          alignment: Alignment.centerLeft,
          decoration: kBoxDecorationStyle,
          height: 60.0,
          child: TextFormField(
            keyboardType: TextInputType.numberWithOptions(),
            autovalidateMode: AutovalidateMode.onUserInteraction,
            autocorrect: false,
            initialValue: phoneNumber.toString(),
            validator: (value) {
              if (value! == '') {
                return 'Please enter Valid Number';
              }
              return null;
            },
            onSaved: (newValue) {
              phoneNumber = int.parse(newValue!);
            },
            style: TextStyle(
              color: Colors.white,
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.only(top: 14.0),
              prefixIcon: Icon(
                Icons.phone,
                color: Colors.white,
              ),
              hintText: 'Enter your Cell Number',
              hintStyle: kHintTextStyle,
            ),
          ),
        ),
      ],
    );
  }

  Widget nameTf() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(
        'Name',
        style: kLabelStyle,
      ),
      SizedBox(height: 10.0),
      Container(
        alignment: Alignment.centerLeft,
        decoration: kBoxDecorationStyle,
        height: 60.0,
        child: TextFormField(
          autovalidateMode: AutovalidateMode.onUserInteraction,
          autocorrect: false,
          initialValue: userName,
          validator: (value) {
            if (value!.isEmpty || value.length < 2) {
              return 'Please enter Valid Name';
            }
            return null;
          },
          onSaved: (newValue) {
            userName = newValue!;
          },
          style: TextStyle(
            color: Colors.white,
          ),
          decoration: InputDecoration(
            border: InputBorder.none,
            contentPadding: EdgeInsets.only(top: 14.0),
            prefixIcon: Icon(
              Icons.account_box,
              color: Colors.white,
            ),
            hintText: 'Enter your Name',
            hintStyle: kHintTextStyle,
          ),
        ),
      ),
    ]);
  }

  Widget provinceTf() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(
        'Province',
        style: kLabelStyle,
      ),
      SizedBox(height: 10.0),
      Container(
        alignment: Alignment.centerLeft,
        decoration: kBoxDecorationStyle,
        height: 60.0,
        child: TextFormField(
          autovalidateMode: AutovalidateMode.onUserInteraction,
          autocorrect: false,
          initialValue: province,
          validator: (value) {
            if (value!.isEmpty || value.length < 2) {
              return 'Please enter Valid Province';
            }
            return null;
          },
          onSaved: (newValue) {
            province = newValue!;
          },
          style: TextStyle(
            color: Colors.white,
          ),
          decoration: InputDecoration(
            border: InputBorder.none,
            contentPadding: EdgeInsets.only(top: 14.0),
            prefixIcon: Icon(
              Icons.account_box,
              color: Colors.white,
            ),
            hintText: 'Enter your Province',
            hintStyle: kHintTextStyle,
          ),
        ),
      ),
    ]);
  }

  Widget _buildTF() {
    return Form(
      autovalidateMode: AutovalidateMode.onUserInteraction,
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            'Email',
            style: kLabelStyle,
          ),
          SizedBox(height: 10.0),
          Container(
            alignment: Alignment.centerLeft,
            decoration: kBoxDecorationStyle,
            height: 60.0,
            child: TextFormField(
              autovalidateMode: AutovalidateMode.onUserInteraction,
              autocorrect: false,
              initialValue: userEmail,
              validator: (value) {
                if (value!.isEmpty || !value.contains('@')) {
                  return 'Please enter Valid email';
                }
                return null;
              },
              onSaved: (newValue) {
                userEmail = newValue!;
              },
              keyboardType: TextInputType.emailAddress,
              style: TextStyle(
                color: Colors.white,
              ),
              decoration: InputDecoration(
                border: InputBorder.none,
                contentPadding: EdgeInsets.only(top: 14.0),
                prefixIcon: Icon(
                  Icons.email,
                  color: Colors.white,
                ),
                hintText: 'Enter your Email',
                hintStyle: kHintTextStyle,
              ),
            ),
          ),
          isLogin ? SizedBox(height: 5) : nameTf(),
          isLogin ? SizedBox(height: 5) : surnameTf(),
          isLogin ? SizedBox(height: 5) : cellNumberTf(),
          isLogin ? SizedBox(height: 5) : provinceTf(),
          Text(
            'Password',
            style: kLabelStyle,
          ),
          SizedBox(height: 10.0),
          Container(
            alignment: Alignment.centerLeft,
            decoration: kBoxDecorationStyle,
            height: 60.0,
            child: TextFormField(
              autovalidateMode: AutovalidateMode.onUserInteraction,
              autocorrect: false,
              initialValue: password,
              validator: (value) {
                if (value!.isEmpty || value.length < 6) {
                  return 'Please enter a stronger Password';
                }
                return null;
              },
              onSaved: (newValue) {
                password = newValue!;
              },
              obscureText: true,
              style: TextStyle(
                color: Colors.white,
              ),
              decoration: InputDecoration(
                border: InputBorder.none,
                contentPadding: EdgeInsets.only(top: 14.0),
                prefixIcon: Icon(
                  Icons.lock,
                  color: Colors.white,
                ),
                hintText: 'Enter your Password',
                hintStyle: kHintTextStyle,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildForgotPasswordBtn() {
    return Container(
      alignment: Alignment.centerRight,
      child: TextButton(
        onPressed: () => print('Forgot Password Button Pressed'),
        child: Text(
          'Forgot Password?',
          style: kLabelStyle,
        ),
      ),
    );
  }

  Widget _buildLoginBtn() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 10.0),
      width: double.infinity,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          minimumSize: Size(200, 50),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: BorderSide(
              width: 1,
              style: BorderStyle.solid,
            ),
          ),
        ),
        onPressed:
            isLogin ? () => _tryLoginUp(context) : () => _trySignUp(context),
        child: Text(
          isLogin ? 'LOGIN' : 'SIGN UP',
          style: TextStyle(
            color: Colors.white,
            letterSpacing: 1.5,
            fontSize: 20.0,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
/* 
  Widget _buildSignInWithText() {
    return Column(
      children: <Widget>[
        Text(
          '- OR -',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w400,
          ),
        ),
        SizedBox(height: 20.0),
        Text(
          'Sign in with',
          style: kLabelStyle,
        ),
      ],
    );
  } */

  /* Widget _buildSocialBtn(Function onTap, AssetImage logo) {
    return GestureDetector(
      onTap: onTap(),
      child: Container(
        height: 60.0,
        width: 60.0,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black26,
              offset: Offset(0, 2),
              blurRadius: 6.0,
            ),
          ],
          image: DecorationImage(
            image: logo,
          ),
        ),
      ),
    );
  } */

/*   Widget _buildSocialBtnRow() {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 30.0),
      child: _buildSocialBtn(
        () => _signInWithGoogle,
        AssetImage(
          'assets/images/google.jpg',
        ),
      ),
    );
  } */

  bool _isLoading = false;

  /* Future<UserCredential> _signInWithGoogle() async {
    setState(() {
      _isLoading = true;
    });
    final googleUser = await GoogleSignIn().signIn();
    final googleAuth = await googleUser!.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );
    final user = await FirebaseAuth.instance.signInWithCredential(credential);
    await FirebaseFirestore.instance
        .collection('Users')
        .doc(user.user!.uid)
        .set({
      'Name': user.user!.displayName,
      'Email': user.user!.email,
      'ImageUrl': user.user!.photoURL,
      'isFirstSell': 'true',
    });
    setState(() {
      _isLoading = false;
    });
    return user;
  } */

  bool isLogin = true;
  Widget _buildSignupBtn() {
    return GestureDetector(
      onTap: () {
        setState(() {
          if (isLogin) {
            isLogin = false;
          } else {
            isLogin = true;
          }
          print(isLogin.toString());
        });
      },
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text:
                  !isLogin ? 'I have an Account ' : 'Don\'t have an Account? ',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.0,
                fontWeight: FontWeight.w400,
              ),
            ),
            TextSpan(
              text: !isLogin ? 'Login' : 'Sign Up',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ScaffoldMessenger(
      key: scaffoldMessengerKey,
      child: Scaffold(
        body: _isLoading
            ? Center(
                child: CircularProgressIndicator.adaptive(),
              )
            : AnnotatedRegion<SystemUiOverlayStyle>(
                value: SystemUiOverlayStyle.light,
                child: GestureDetector(
                  onTap: () => FocusScope.of(context).unfocus(),
                  child: Stack(
                    children: <Widget>[
                      Container(
                        height: double.infinity,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              Colors.blueAccent,
                              Colors.lightBlue,
                              Colors.lightBlueAccent
                            ],
                          ),
                        ),
                      ),
                      Container(
                        height: double.infinity,
                        child: SingleChildScrollView(
                          physics: AlwaysScrollableScrollPhysics(),
                          padding: EdgeInsets.symmetric(
                            horizontal: 40.0,
                            vertical: 120.0,
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                'Welcome To',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'OpenSans',
                                  fontSize: 30.0,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: 10.0),

                              Text(
                                'Inkomba',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'OpenSans',
                                  fontSize: 50.0,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),

                              SizedBox(height: 30.0),
                              SizedBox(
                                height: 20.0,
                              ),
                              _buildTF(),
                              _buildForgotPasswordBtn(),
                              _buildLoginBtn(),
                              //_buildSignInWithText(),
                              //_buildSocialBtnRow(),
                              _buildSignupBtn(),
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}
