import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:inkomba_poc/widgets/starRating.dart';

class MyProfileScreen extends StatefulWidget {
  final bool isEmployer;
  const MyProfileScreen({Key? key, required this.isEmployer}) : super(key: key);

  @override
  _MyProfileScreenState createState() => _MyProfileScreenState();
}

class _MyProfileScreenState extends State<MyProfileScreen> {
  @override
  Widget build(BuildContext context) {
    final double rating = 3.5;
    final user = FirebaseAuth.instance.currentUser!.uid;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Stack(children: <Widget>[
          Container(
            height: double.infinity,
            width: double.infinity,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.blueAccent,
                  Colors.lightBlue,
                  Colors.lightBlueAccent
                ],
              ),
            ),
          ),
          FutureBuilder(
              future: FirebaseFirestore.instance
                  .collection('Users')
                  .doc('$user')
                  .get(),
              builder: (context,
                  AsyncSnapshot<DocumentSnapshot<Map<String, dynamic>>>
                      snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(
                    child: CircularProgressIndicator.adaptive(),
                  );
                }
                final data = snapshot.data!.data()!;
                return Column(
                  children: [
                    Container(
                      padding: EdgeInsets.only(top: 35),
                      child: Icon(
                        Icons.face,
                        size: 80,
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(15),
                      child: Center(
                          child: Text(
                        data['Name'],
                        style: Theme.of(context).textTheme.headline6,
                      )),
                    ),
                    Container(
                      child: InfoCard(
                          isAcredited: true,
                          cat: 'Email',
                          iconData: Icons.email,
                          info: data['Email']),
                    ),
                    Container(
                      child: InfoCard(
                          isAcredited: false,
                          cat: 'Location',
                          iconData: Icons.pin_drop,
                          info: data['Province']),
                    ),
                    Container(
                      child: InfoCard(
                          isAcredited: true,
                          cat: 'Phone Number',
                          iconData: Icons.phone,
                          info: data['PhoneNumber'].toString()),
                    ),
                    Container(
                      child: widget.isEmployer
                          ? InfoCard(
                              isAcredited: true,
                              cat: 'Business type',
                              iconData: Icons.gamepad_rounded,
                              info: data['BusinessType'].toString())
                          : InfoCard(
                              isAcredited: true,
                              cat: 'Skills',
                              iconData: Icons.gamepad_rounded,
                              info: data['Skills'].toString()),
                    ),
                    Container(
                      child: widget.isEmployer
                          ? InfoCard(
                              isAcredited: true,
                              cat: 'Business Name',
                              iconData: Icons.games_sharp,
                              info: data['BusinessName'].toString())
                          : InfoCard(
                              isAcredited: true,
                              cat: 'Training',
                              iconData: Icons.games_sharp,
                              info: data['Training'].toString(),
                            ),
                    ),
                    Container(
                      child: StarDisplay(
                        value: rating,
                      ),
                    ),
                  ],
                );
              }),
        ]),
      ),
    );
  }
}

class InfoCard extends StatelessWidget {
  final String info;
  final String cat;
  final bool isAcredited;
  final IconData iconData;
  const InfoCard({
    required this.info,
    required this.cat,
    required this.isAcredited,
    required this.iconData,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Container(
        height: 75,
        width: 300,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [
              Colors.blueAccent,
              Colors.lightBlue,
              Colors.lightBlueAccent
            ],
          ),
        ),
        child: ListTile(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
            leading: Icon(iconData),
            title: Text(info),
            subtitle: Text(cat),
            trailing: isAcredited ? Icon(Icons.check) : null),
      ),
    );
  }
}
