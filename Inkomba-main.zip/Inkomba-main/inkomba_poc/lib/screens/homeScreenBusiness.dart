import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:inkomba_poc/screens/MyProfileScreeen.dart';
import 'package:inkomba_poc/screens/giveReferralScreen.dart';

class HomeScreenBusiness extends StatefulWidget {
  const HomeScreenBusiness({Key? key}) : super(key: key);

  @override
  _HomeScreenBusinessState createState() => _HomeScreenBusinessState();
}

class _HomeScreenBusinessState extends State<HomeScreenBusiness> {
  @override
  void initState() {
    super.initState();
    initDynamicLinks();
  }

  void initDynamicLinks() async {
    FirebaseDynamicLinks.instance.onLink(
        onSuccess: (PendingDynamicLinkData? dynamicLink) async {
      final Uri? deepLink = dynamicLink?.link;

      if (deepLink != null) {
        Navigator.pushNamed(context, deepLink.path);
      }
    }, onError: (OnLinkErrorException e) async {
      print('onLinkError');
      print(e.message);
    });

    final PendingDynamicLinkData? data =
        await FirebaseDynamicLinks.instance.getInitialLink();
    final Uri? deepLink = data?.link;

    if (deepLink != null) {
      Navigator.pushNamed(context, deepLink.path);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButtonLocation: FloatingActionButtonLocation.centerTop,
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => FirebaseAuth.instance.signOut(),
          label: Text('SignOut'),
          icon: Icon(
            Icons.logout,
          ),
        ),
        body: AnnotatedRegion<SystemUiOverlayStyle>(
          value: SystemUiOverlayStyle.light,
          child: Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
              Colors.blueAccent,
              Colors.lightBlue,
              Colors.lightBlueAccent
            ], begin: Alignment.topLeft, end: Alignment.bottomRight)),
            child: Stack(
              children: [
                MyProfileWidget(),
                Positioned(
                  right: 40,
                  top: 50,
                  child: FindJobsWidget(
                    classNav: null, //TODO: Implement Nav to post Jobs,
                    icon: Icons.cases,
                    title: 'Post Jobs',
                  ),
                ),
                Positioned(
                  left: 33,
                  bottom: 50,
                  child: FindJobsWidget(
                    classNav:
                        GiveReferralScreen(),
                    icon: Icons.qr_code,
                    title: 'Give Referral',
                  ),
                ),
                Positioned(
                  left: 50,
                  top: 50,
                  child: FindJobsWidget(
                    icon: Icons.calendar_today,
                    title: 'Schedule',
                  ),
                ),
                Positioned(
                  right: 10,
                  bottom: 50,
                  child: FindJobsWidget(
                    icon: Icons.center_focus_strong,
                    title: 'Register as \n Training Centres',
                  ),
                ),
              ],
            ),
          ),
        ));
  }
}

class FindJobsWidget extends StatelessWidget {
  final String title;
  final IconData icon;
  final classNav;
  const FindJobsWidget({
    this.classNav,
    required this.title,
    required this.icon,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => classNav,
            )),
        child: Column(
          children: [
            Icon(
              icon,
              size: 40,
            ),
            Text(
              title,
              style: TextStyle(fontSize: 20),
            ),
          ],
        ));
  }
}

class MyProfileWidget extends StatelessWidget {
  const MyProfileWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => MyProfileScreen(
            isEmployer: true,
          ),
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            alignment: Alignment.center,
            child: GestureDetector(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => MyProfileScreen(
                    isEmployer: true,
                  ),
                ),
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Icon(
                    Icons.account_circle,
                    size: 60,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 80.0),
                    child: Text(
                      'My Profile',
                      style: TextStyle(fontSize: 28),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
