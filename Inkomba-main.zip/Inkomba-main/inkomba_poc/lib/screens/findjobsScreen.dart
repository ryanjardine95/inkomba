import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class FindJobs extends StatelessWidget {
  const FindJobs({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          systemOverlayStyle: SystemUiOverlayStyle(
            statusBarColor: Colors.green,
            statusBarBrightness: Brightness.dark,
          ),
          backgroundColor: Colors.lightBlue,
          elevation: 0,
          centerTitle: true,
          title: Text('Jobs Near Me'),
        ),
        body: StreamBuilder(
          stream: FirebaseFirestore.instance.collection('Jobs').snapshots(),
          builder: (ctx, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(
                child: CircularProgressIndicator.adaptive(),
              );
            }
            final data = snapshot.data!.docs;
            return ListView.builder(
              itemCount: data.length,
              itemBuilder: (ctx, i) => Card(
                elevation: 8,
                child: ExpansionTile(
                  childrenPadding: EdgeInsets.all(15),
                  tilePadding: EdgeInsets.all(5),
                  children: [
                    Center(
                      child: ElevatedButton(
                        onPressed: () {},
                        child: Text('Apply For Job'),
                      ),
                    ),
                  ],
                  title: JobContainer(
                    title: data[i]['Skills Required'],
                    description: "${data[i]['Job Description']}",
                    duration: "${data[i]['Duration']}",
                    location: data[i]['Location'],
                    salary: data[i]['Payment'],
                    employer: data[i]['Employer'],
                  ),
                ),
              ),
            );
          },
        ));
  }
}

class JobContainer extends StatelessWidget {
  final String title;
  final String location;
  final String description;
  final String salary;
  final String duration;
  final String employer;

  const JobContainer({
    required this.title,
    required this.duration,
    required this.location,
    required this.description,
    required this.salary,
    required this.employer,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 15.0, horizontal: 5.0),
        padding: const EdgeInsets.all(15.0),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(9.0),
          boxShadow: [BoxShadow(blurRadius: 5.0, offset: Offset(0, 3))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                SizedBox(width: 15),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        "$title",
                        style: Theme.of(context).textTheme.headline6,
                      ),
                      Text(
                        "$location",
                        style: Theme.of(context).textTheme.bodyText1,
                      ),
                      Text(
                        "$employer",
                        style: Theme.of(context).textTheme.bodyText1,
                      ),
                      SizedBox(height: 10),
                      Text(
                        "$description",
                        maxLines: 3,
                        style: Theme.of(context).textTheme.bodyText2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 9),
                      Text(
                        "$duration",
                        maxLines: 3,
                        style: Theme.of(context).textTheme.bodyText2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 9),
                      Text(
                        "$salary",
                        style: Theme.of(context).textTheme.bodyText1,
                      )
                    ],
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
