import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';

class QRcodeScreen extends StatefulWidget {
  const QRcodeScreen({Key? key}) : super(key: key);

  @override
  _QRcodeScreenState createState() => _QRcodeScreenState();
}

class _QRcodeScreenState extends State<QRcodeScreen> {
  final user = FirebaseAuth.instance.currentUser!.uid;
  Uri? shortUrl;


  Future<void> _createDynamicLink() async {
    final DynamicLinkParameters parameters = DynamicLinkParameters(
      uriPrefix: 'https://inkomba.page.link',
      link: Uri.parse('https://inkomba.page.link/referrals/?id=$user'),
      androidParameters: AndroidParameters(
        packageName: 'com.example.inkomba_poc',
        minimumVersion: 1,
      ),
    );

    final ShortDynamicLink shortDynamicLink = await parameters.buildShortLink();
    setState(() {
      shortUrl = shortDynamicLink.shortUrl;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: Padding(
        padding: const EdgeInsets.all(8.0),
        child: FloatingActionButton.extended(
          onPressed: () => Navigator.pop(context),
          label: Text('Done!'),
          icon: Icon(Icons.close),
        ),
      ),
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Stack(children: <Widget>[
            Container(
              height: double.infinity,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.blueAccent,
                    Colors.lightBlue,
                    Colors.lightBlueAccent
                  ],
                ),
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 75, right: 50),
                  child: Text(
                    'My Referral Code',
                    style: TextStyle(fontSize: 28),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 75, right: 50),
                  child: QrImage(
                    data: '$shortUrl',
                    version: QrVersions.auto,
                    size: 200.0,
                  ),
                ),
                Padding(
                    padding: const EdgeInsets.only(left: 75, right: 50),
                    child: ElevatedButton(
                      onPressed: ()=>_createDynamicLink(),
                      child: Text('Generate New QR Code'),
                    )),
              ],
            ),
          ]),
        ),
      ),
    );
  }
}
