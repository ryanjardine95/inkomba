import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:inkomba_poc/models/locationModel.dart';
import 'package:inkomba_poc/models/location_helper.dart';
import 'package:inkomba_poc/widgets/location_input.dart';

class WorkerOrEmployee extends StatefulWidget {
  const WorkerOrEmployee({Key? key}) : super(key: key);

  @override
  _WorkerOrEmployeeState createState() => _WorkerOrEmployeeState();
}

bool _isChosen = false;
String userType = '';
final List<String> skillsCat = ['Skill', 'Brick Layer', 'Domestic Worker'];
final List<String> trainingCat = [
  'Training',
  'Construcion Business',
  'Self Taught'
];
final List<String> businesTypeCat = [
  'Business Type',
  'Construction Company',
  'Cleaning Service'
];

String selectedSkill = 'Skill';
String selectedBusinessType = 'Business Type';
TextEditingController businessName = new TextEditingController();

LocationModel? locationHelper;
String address = '';
void _selectPlace(double lat, double lng) async {
  locationHelper = LocationModel(latitiude: lat, longitude: lng);
  address = await LocationHelper.getPlacesAdress(
    lat: locationHelper!.latitiude!,
    lng: locationHelper!.longitude!,
  );
  print(address);
}

String selectedTraining = 'Training';

class _WorkerOrEmployeeState extends State<WorkerOrEmployee> {
  Future<void> chooseUserType(String userTypeButton) async {
    setState(() {
      _isChosen = true;
      userType = userTypeButton;
    });
  }

  Future<void> setUserType(String userTypeButton) async {
    final fireabse = FirebaseFirestore.instance.collection('Users');
    final uid = FirebaseAuth.instance.currentUser!.uid;

    if (userType == 'Employee') {
      await fireabse.doc(uid).update({
        'UserType': userType,
        'Skills': selectedSkill,
        'Training': selectedTraining,
        'Location': address
      });
    } else {
      await fireabse.doc(uid).update({
        'UserType': userType,
        'BusinessName': businessName.text,
        'BusinessType': selectedBusinessType,
        'Location': address,
      });
    }

    Navigator.pop(context);
  }

  Widget workerOrEmployee() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        Center(
          child: Text(
            'Looking to',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          ),
        ),
        ElevatedButton(
          child: Text(
            'Work?',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          onPressed: () => chooseUserType('Employee'),
          style: ElevatedButton.styleFrom(
            minimumSize: Size(250, 50),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
              side: BorderSide(
                width: 1,
                style: BorderStyle.solid,
              ),
            ),
          ),
        ),
        Center(
          child: Text('Or'),
        ),
        ElevatedButton(
          child: Text(
            'Hire?',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          onPressed: () => chooseUserType('Business'),
          style: ElevatedButton.styleFrom(
            minimumSize: Size(250, 50),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
              side: BorderSide(
                width: 1,
                style: BorderStyle.solid,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget getLastInfo() {
    return userType == 'Employee'
        ? Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(25),
                  child: const Text(
                    'Please tell us about yourself',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: DropdownButtonFormField(
                  isExpanded: true,
                  onChanged: (String? string) {
                    selectedSkill = string!;
                  },
                  hint: Text('Skills'),
                  items: skillsCat.map((String string) {
                    return DropdownMenuItem(
                      child: Text(string),
                      value: string,
                    );
                  }).toList(),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: DropdownButtonFormField(
                  isExpanded: true,
                  onChanged: (String? string) {
                    selectedTraining = string!;
                  },
                  hint: Text('Training'),
                  items: trainingCat.map((String string) {
                    return DropdownMenuItem(
                      child: Text(string),
                      value: string,
                    );
                  }).toList(),
                ),
              ),
              LocationInput(
                _selectPlace,
              ),
              ElevatedButton(
                child: Text(
                  'Save',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                onPressed: () => setUserType('Employee'),
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(250, 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                    side: BorderSide(
                      width: 1,
                      style: BorderStyle.solid,
                    ),
                  ),
                ),
              ),
            ],
          )
        : Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(25),
                  child: const Text(
                    'Please tell us about your Business',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: DropdownButtonFormField(
                  isExpanded: true,
                  onChanged: (String? string) {
                    selectedBusinessType = string!;
                  },
                  hint: Text('Business Type'),
                  items: businesTypeCat.map((String string) {
                    return DropdownMenuItem(
                      child: Text(string),
                      value: string,
                    );
                  }).toList(),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: TextField(
                  controller: businessName,
                  decoration: InputDecoration(
                    hintText: 'Enter Business Name'
                  ),
                  onSubmitted: (string) {
                    businessName.text = string;
                  },
                ),
              ),
              LocationInput(
                _selectPlace,
              ),
              ElevatedButton(
                child: Text(
                  'Save',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                onPressed: () => setUserType('Employee'),
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(250, 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                    side: BorderSide(
                      width: 1,
                      style: BorderStyle.solid,
                    ),
                  ),
                ),
              ),
            ],
          );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Stack(
            children: <Widget>[
              Container(
                height: double.infinity,
                width: double.infinity,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Colors.blueAccent,
                      Colors.lightBlue,
                      Colors.lightBlueAccent
                    ],
                  ),
                ),
              ),
              Container(
                height: double.infinity,
                child: !_isChosen ? workerOrEmployee() : getLastInfo(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
