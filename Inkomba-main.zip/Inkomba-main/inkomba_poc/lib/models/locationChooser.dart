class LocationChooser {
  final double? latitude;
  final double? longitude;

  const LocationChooser({this.latitude, this.longitude});
}