import 'dart:convert';

import 'package:http/http.dart' as http;

class LocationHelper {
  static String generateLocationPreviewImage({
    double? latitude,
    double? longitude,
  }) {
    return 'https://maps.googleapis.com/maps/api/staticmap?center=&$latitude,$longitude&=13&size=600x300&maptype=roadmap&markers=color:red%7Clabel:C%7C$latitude, $longitude&key=AIzaSyDWBJIn5vZkqb7HISNaVPvDYHP1c926lDg';
  }

  static Future<String> getPlacesAdress({double? lat, double? lng}) async {
    print('$lat,$lng');
    final url =
        'https://maps.googleapis.com/maps/api/geocode/json?latlng=$lat,$lng&key=AIzaSyDWBJIn5vZkqb7HISNaVPvDYHP1c926lDg';
    final response = await http.get(Uri.parse(url));

    final responseData =
        await json.decode(response.body)['results'][0]['formatted_address'];
    return responseData;
  }
}
