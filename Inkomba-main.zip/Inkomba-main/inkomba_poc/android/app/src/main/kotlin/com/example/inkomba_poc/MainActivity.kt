package com.example.inkomba_poc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
